import React from 'react'
import Welcome from '../component/Welcome';
import Courses from '../component/Courses';
import Footer from '../component/Footer';
import Navbar from '../component/Navbar/Navbar';
import Admission from '../component/Admission';
import Know from '../component/Know';
//import Modal from '../component/modal/modal'




const LandingPage = () => {

  return (
    <div>
     
      <Navbar/>
      <Admission/>
      <Welcome/>
      <Courses/>
      <Know/>
      <Footer/>
     
    </div>
  );
};

export default LandingPage;
