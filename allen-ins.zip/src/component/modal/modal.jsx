import { useState } from 'react';
import './modal.css'



const modal= () => {
  return (
    <>
    <h2>WELCOME TO ALLEN</h2>
    <P>
      Allen is launching a new program which is now called as alpha batch from 1st march 2024....
    </P>
    <button onClick={}>OK</button>
    
    </>
    )
  }
  
  export default modal;
  