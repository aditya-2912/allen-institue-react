import React from 'react';
import './admission.css';
import { Button } from 'react-bootstrap';

const Admission = () => {
    return (
      <>
      <div div className="Container">
      <div className='image-container'>
        <img src="https://cdn.allennext.com/fe-bsite/static/NewHomePage/Building.webp"alt="students"style={{width:'100%',height:"700px",border:"2px solid black"}}/>
     
     
<div className='card-img-overlay ' style={{fontWeight:"bold"}}>
<p class="card-text" style={{textAlign:"center", fontSize:"90px", color:"black",background:"grey", borderRadius:"20px"}}>Start your journey with ALLEN.</p>



<div className="d-grid gap-7 col-9 mx-auto">
  <button className="btn btn-primary" type="button" style={{color:"yellow", backgroundColor:"blue", fontWeight:"bold", fontSize:"40px", borderRadius:"20px"}}>ADMISSION   OPEN FOR ALL COURSES(Session 2024-25) </button>
  </div>
</div>
</div>
</div>      
      
  
    </>
    );
};
export default Admission;