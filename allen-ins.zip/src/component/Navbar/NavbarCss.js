 import { makeStyles } from "@mui/styles";

export const useStyles=makeStyles({
    divStyle:{
        width:'100%',
        height:'20vh',
        backgroundColor: '#4caf5ye',
position:'fixed',
        
    }
}) 