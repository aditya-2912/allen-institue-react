import React from 'react';
import './know.css';


const Know = () => {
 
    return (
        <>
        <div className='heroine'>
         <div className='container'>
        <div className='left-section'style={{paddingRight:"10px"}}>
        < img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/about-icon01.png" className="rounded float-end " alt="know"style={{width:"250px"}}/>
        </div>
        
        <div className='container'>
        <div className='left-section'>
        
        < img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/about-icon02.png" className="rounded float-end " alt="know"style={{width:"250px"}}/>
        </div>
        <div className='container'>
        <h2 className='new-heading' style={{fontWeight:"700", fontSize:"35px", padding:"4px",fontFamily:"Source Sans Pro"}}>Know about <span style={{fontSize:"60px"}}>ALLEN</span></h2>
        </div>
          <div className='container'>
          <p className='text-start' style={{   textAlign:"justify" ,  boxSizing:"border-box", padding:"3px",justifyContent:"center"}}>A Premier Coaching Institute for the preparation of JEE (Main+Advanced), JEE (Main), Pre-Medical (NEET-UG), Pre-Nurture & Career Foundation (Class VI to X, NTSE & Olympiads) and Commerce Education (11th, 12th, CA & CS). The Institute is well regarded for the high quality entrance exam preparation and produces best results year after year. At ALLEN , We focus on building a strong foundation of knowledge and concepts in students for their success and provide an excellent platform for the preparation of competitive exams and board level education. The best academic support and personal care which we provide to the students, helps them meet their career goals and objectives. The core values of Determination, Honesty, Authenticity, Integrity, Devotion, Humanism, Holistic Learning, Social Ethics, and concern for society & environment are all closely interwoven into the fiber of our academic programs. Our highly qualified and most experienced faculties are dedicated and committed to student’s complete success and provide assistive surroundings to contribute to their social, cultural, academic and all-round development.</p>
          </div>
         
         </div>
</div>
</div>
  </>
  );
};
export default Know;