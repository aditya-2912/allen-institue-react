import React from 'react';
import './footer.css'; 
const Footer = () => {
  return (
    <footer className="footer">
        <div className="Footer-grid">
      <div className="footer-section">
      <h3>About Us</h3>
        <ul>
          <li><a href="/About ALLEN">About ALLEN</a></li>
          <li><a href="/Our Inspiration">Our Inspiration</a></li>
          <li><a href="/Directors Message">Directors Message</a></li>
          <li><a href="/Contactt">Contact</a></li>
          <li><a href="/ALLEN System">ALLEN System</a></li>
          <li><a href="/Lead With ALLEN">Lead With ALLEN</a></li>
          <li><a href="/ALLEN World Records">ALLEN World Records</a></li>
          <li><a href="/Disclosure, Policies & Documents">Disclosure, Policies & Documents</a></li>

        </ul>
      </div>
      <div className="footer-section">
        <h3>Courses & Programmes</h3>
        <ul>
          <li><a href="/All Competitive Exams (ACE)">All Competitive Exams (ACE)</a></li>
          <li><a href="/JEE (Main+Advanced)">JEE (Main+Advanced)</a></li>
          <li><a href="/Pre-Medical NEET (UG)">Pre-Medical NEET (UG)</a></li>
          <li><a href="/contact">Contact</a></li>
          <li><a href="/JEE Main">JEE Main</a></li>
          <li><a href="/PNCF (Class 6th to 10th)">PNCF (Class 6th to 10th)</a></li>


          <li><a href="/Distance Learning">Distance Learning</a></li>
          <li><a href="/Workshops">Workshops</a></li>

        </ul>
      </div>
      <div className="footer-section">
        <h3>Results</h3>
        <ul>
          <li><a href="/"></a></li>
          <li><a href="/JEE-adv">JEE (Advanced) - IIT JEE</a></li>
          <li><a href="/AIIMS">AIIMS</a></li>
          <li><a href="/JEE-MAINS">JEE (Main) - AIEEE</a></li>
          <li><a href="/Olympaid">Olympiad, NTSE, KVPY, Scholarship etc</a></li>
        </ul>
        <h3>Websites</h3>
        <ul>
          <li><a href="/">TALLENTEX</a></li>
          <li><a href="/about">ALLEN Digital</a></li>
          <li><a href="/services">ALLEN Champ</a></li>
          <li><a href="/contact">ALLEN Alumni Network</a></li>

        </ul>

      </div>
      <div className="footer-section">
        <h3>Exam Information</h3>
        <ul>
        <li><a href="/JEE MAIN">JEE Main</a></li>
          <li><a href="/JEE ADVANCED">JEE Advanced</a></li>
          <li><a href="/NEET UG">NEET UG</a></li>
          <li><a href="/Boards">Boards</a></li>
        </ul>
        
      </div>
     </div>

      <div className="footer-section01">
      ALLEN Career Institute Private Limited
(CIN: U80100RJ2021PTC077131)
Registered & Corporate Office : “SANKALP”, CP-6, Indra Vihar, Kota (Rajasthan) - 324005
      </div>
      <div className="footer-section02">
      ALLEN Career Institute Pvt. Ltd. © All Rights Reserved.
      </div>
      </footer>


  );
};

export default Footer;