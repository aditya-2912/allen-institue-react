import { useEffect, useState } from "react";
import { Button, AppBar, Box, CssBaseline, IconButton, Toolbar, Typography, Menu, MenuItem } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import { styled, alpha } from '@mui/material/styles';
import SearchIcon from '@mui/icons-material/Search';

import InputBase from '@mui/material/InputBase';
import { ClassNames } from "@emotion/react";
export default function Contact(props) {

  return (
  
  <div style={{backgroundColor:"black",width:"100%"}}>
<nav className="nav"style={{marginLeft:"400px",paddingTop:"180px"}}>
  <div className="dropdown">
  <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"style={{fontSize:"20px"}}>
    Study Centers
  </button>
  <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><a className="dropdown-item" href="#">Kota</a></li>
    <li><a className="dropdown-item" href="#">Akola</a></li>
    <li><a className="dropdown-item" href="#">Alwar</a></li>
    <li><a className="dropdown-item" href="#">Bengaluru</a></li>
    <li><a className="dropdown-item" href="#">Bhopal</a></li>
    <li><a className="dropdown-item" href="#">Chennai</a></li>
    <li><a className="dropdown-item" href="#">Delhi</a></li>
    <li><a className="dropdown-item" href="#">Gwalior</a></li>
    <li><a className="dropdown-item" href="#">Kochi</a></li>
    <li><a className="dropdown-item" href="#">Mumbai</a></li>
    <li><a className="dropdown-item" href="#">Ujjain</a></li>
  </ul>
</div>
  <a className="nav-link All India Information Centers"  href="#"style={{textcolor:"black",fontSize:"20px"}}>All India Information Centers</a>
  <a className="nav-link ASAT Centers" href="#"style={{fontSize:"20px"}} >ASAT Centers</a>
</nav>
<div className="container"style={{textAlign:"center",paddingTop:"150px",marginLeft:"300px"}}>
 <div className="row">
  <div className="col-sm-12 col-md-2 column-1 text-md-text">
<div className="card" style={{width:"15rem",height:"13rem",padding:"3px"}}>
  <div className="img-e">
  <img src="https://www.allen.ac.in/map/icon-phone.png"className="text-center"alt='contact'style={{width:"70px" }}/>
 </div>
  <div className="card-body">
    <h5 className="card-title"style={{textAlign:"center",fontSize:"17px",fontWeight:"bold"}}>Call<small>(08:00AM to 08:00PM)</small></h5>
    <a href="#"className="card-subtitle">+91-744-3556677</a>
   </div>
   </div>
   </div>
  
  <div class="col-sm-2">
    <div className="card" style={{width:"15rem",height:"13rem"}}>
      <div className="ima-phone">
  <img src="https://www.allen.ac.in/map/icon-envelope.png"className="text-center"alt='contact'style={{width:"70px"}}/>
  </div>
  
  <div className="card-body">
    <h5 className="card-title"style={{textAlign:"center",fontSize:"17px",fontWeight:"bold"}}>Email</h5>
    
    <a href="#" className="text-center">info@allen.in</a>
   </div>
   </div>
  </div>
  <div class="col-sm-2">
    <div className="card" style={{width:"15rem",height:"13rem",paddingTop:"8px"}}>
      <div className="img-ema">
  <img src="https://www.allen.ac.in/map/get-support-icon.png"className="text-center"alt='contact'style={{width:"80px"}}/>
  </div>
  <div className="card-body">
    <h5 className="card-title"style={{textAlign:"center",fontSize:"17px",fontWeight:"bold"}}>Get Support</h5>
    <a href="#" className="text-center">Click Here</a>
   </div>
   </div>
   </div>
   <div class="col-sm-2">
    <div className="card" style={{width:"15rem",height:"13rem",paddingTop:"10px"}}>
      <div className="img-loc">
  <img src="https://www.allen.ac.in/map/icon-location.png"className="text-center"alt='contact'style={{width:"60px"}}/>
  </div>
  <div className="card-body">
    <h5 className="text-center"style={{fontSize:"17px",fontWeight:"bold"}}>Address</h5>
    <a href="#"className="text-center">Sankalp,CP Kota</a>
   
   </div>
   </div>
   </div>
</div>
</div>
</div>
  
   );
}