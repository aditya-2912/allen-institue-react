import React from 'react';
import './welcome.css';


const Welcome = () => {
  return (
   <>
    <div className='container'style={{ marginTop:"10px",width:"100%"}}>
     
          <div className="text-end" style={{margin:"40px", padding:"0px"}}>
          <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/slider/top-slider/Enthusiast-Course--jee-advanced-banner.jpg" className="rectangle-circle"alt='welcome'/>
          </div>
          </div>
           <div className='container'>
            <div className='text-heading'>
            <h2 className='text-center' style={{fontFamily:"Source Sans Pro", fontSize:"70px", color:'black', margin:"2px",padding:"2px" ,fontWeight:"700"}}>Welcome Allen Career Institute.</h2>
           </div>
           </div>
           <div className='container'>
            <div className='text-para'>
            <p className='text-start'style={{fontSize:"20px",color:"black", padding:"8px", textAlign:"center"}}>Kota, the Kashi of Education, is all set to begin the offline classes. 
        The city is well prepared to welcome the students after receiving the state 
        government permission. <strong style={{fontSize:"30px"}}>Mr. Naveen Maheshwari</strong> Director of ALLEN Career Institute, said,
         We are equipped with all the ensure.</p>
           </div>
            </div>
</>

       
    
  );
};
export default Welcome;