import { useEffect, useState } from "react";
import { Button, AppBar, Box, CssBaseline, IconButton, Toolbar, Typography, Menu, MenuItem } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import { styled, alpha } from '@mui/material/styles';
import SearchIcon from '@mui/icons-material/Search';

import InputBase from '@mui/material/InputBase';
import { ClassNames } from "@emotion/react";
export default function About(props) {

  return (
<>
<div id="carouselExampleControls" className="carousel slide" data-bs-ride="carousel">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src="https://750goldratepatna.today/wp-content/uploads/2023/10/allen-institute-patna-fee.jpg" className="d-block" alt="about"style={{width:"100%",height:"700px",paddingTop:"50px",paddingBottom:"40px",paddingLeft:"50px",paddingRight:"50px",border:"2px solid black"}}/>
    </div>
    <div className="carousel-item">
      <img src="https://myexam.allen.ac.in/wp-content/uploads/2020/06/allen-overseas-online-classes.jpg" className="d-block" alt="about"style={{width:"100%",height:"700px",paddingTop:"50px",paddingBottom:"40px",paddingLeft:"50px",paddingRight:"50px",border:"2px solid black"}}/>
    </div>
    <div className="carousel-item">
      <img src="https://csat.allen.ac.in/document/student/studentImage/750X530_jee.jpg" className="d-block " alt="about"style={{width:"100%",height:"700px",paddingTop:"50px",paddingBottom:"40px",paddingLeft:"50px",paddingRight:"50px",border:"2px solid black"}}/>
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

  

 
 
 
  <div className="container">
    
  <h2 style={{paddingBottom:"20px",color:"black",fontSize:"40px"}}>About ALLEN</h2>
  </div>
  <div className="container">
  <h4 style={{paddingBottom:"15px"}}>An Enduring <span style={{color:"red"}}>Foundation</span></h4>
  </div>
  <div className="container" >
    <p className="text"style={{backgroundColor:"green",fontSize:"20px",color:"whitesmoke",position:"relative",marginBottom:"25px",paddingBottom:"10px",paddingLeft:"10px",paddingRight:"10px",paddingTop:"10px"}}> Necessity is the Mother of invention but here it is the Mother of Miracle. A Miracle which has grown manifold - ALLEN CAREER INSTITUTE . ALLEN Career Institute is a pioneer institute in the field of coaching for Competitive Exams. Founded on April 18, 1988 and named in the loving memory of Late Shri Laxmi Narayan Maheshwari, father of four brothers Shri Govind, Shri Rajesh, Shri Naveen & Shri Brajesh Maheshwari, ALLEN has today become a synonym of SUCCESS.</p>
  </div>
  <div className="container">
    <p className="text">In 1988, Shri Rajesh Maheshwari started with just eight students and after a few months Dr. K.G.Vaishnava, the eminent professor of Biology also joined him. It was the only institute of its time which provided coaching for all Science subjects i.e. Physics,Chemistry, Biology and Mathematics under one roof. This strong association became the foundation stone of the revolutionary Pre-Medical coaching institute of that time.</p>
 </div>
 <div className="container">
    <p className="text">New heights of success were scaled year after year. The Institute achieved remarkable Landmark of 12 selections in Rajasthan PMT in the year 1991.</p>
 </div>
 <div className="container">
    <p className="text">Meanwhile, Er. Brajesh Maheshwari, a dynamic person with excellent engineering background joined the team. The consistent and ideal team efforts of faculty members, the vivid educational philosophy of all the HODs and the visionary administration of Shri Rajesh Maheshwari altogether laid the path of glorious success, which led the institute to achieve First Rank in Rajasthan PMT in 1995. Since then, ALLEN is known to create ‘never before’ benchmarks.The past achievements were complemented with remarkable progress when our Classroom Coaching Students bagged the All India First Ranks in both the prestigious examinations of India, JEE Advanced 2014 and AIPMT 2014 respectively. In 2016, ALLEN broke it's own stupendous records of previous year results by becoming the first ever Institute of the country to produce <span style={{fontWeight:"bold"}}>All India Ranks 1,2,3 in both JEE Advanced and NEET- UG from classroom.</span></p>
 </div>
 <div className="container">
    <p className="text">ALLEN Career Institute is a symbol of united family of four devoted brothers, which has grown up to a large group of 16000+ members as on date, with trust of more than 30 lac + Student in all modes since 1988.The Institute is in parallel with Indian values, spiritualism & hard work under the efficient directions of Shri Govind Maheshwari, Shri Naveen Maheshwari - with the pious wishes of mother Smt. Krishnadevi Maheshwari & blessings of the most revered Jagadguru Ramanujacharya Shri Jhalaria Peethadhishwar Swamiji Shri Ghanshyamacharya Ji Maharaj.</p>
 </div>
 <div className="container">
    <p className="text">With this, the institute is on its “Path to Success...” by writing its success story and adding more episodes of splendid achievements year after year.</p>
 </div>
 <div className="container">
   <blockquote>
    <em style={{fontSize:"20px"}}> Dream is not that which you see while sleeping; it is something that does not let you sleep<br></br>.</em>
    <small style={{fontSize:"20px"}}><em>-A.P.J. Abdul Kalam</em>
    </small>

</blockquote>
    
 </div>
 </>

  );
}