import React from 'react'
import './courses.css';

const  Courses = () => {
 
      return (
       <>
       <div className='hero'>
        <div className='container mt-5' style={{padding:"9px", paddingTop:"1px"}}></div>
       <h1 style={{fontFamily:"Source Sans Pro", fontSize:"70px", color:'black', textAlign:'center', marginBottom:"5px" ,fontWeight:"700"}}>Popular Courses</h1>
       
       <div class="row row-cols-3 row-cols-md-3 g-7" style={{padding:"8%",margin:"10px", paddingTop:"2px"}}>
  <div className="col">
        <div className="card btn-group text-white bg-dark mb-3 border-info mb-3" style={{width:"350px",borderRadius:"60px",boxShadow:"4px 4px green" }}>
    <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/course-icon03.png"style={{width:"350px",height:"200px", backgroundColor:"lightblue", padding:"0.5rem"}} className="card-img-top" alt="..."/>
     <div className="card-body">
      <h2 className="card-title" style={{fontFamily:"Source Sans Pro"}}>Pre-Medical NEET (UG)</h2>
      <p className="card-text" style={{color:"white", fontSize:"9px"}}>Our Pre-Medical Division at ALLEN gwalior equipped with the top most faculty team who has produced many top ranks in earlier periods. The basic fundamentals are explained in an easy manner via illustration. Systematic well planned classes and the well the syllabus give enough time to medical aspirants for self-study and rigorous practice at home.</p>
    <label className="btn btn-outline-primary" for="btncheck1">View Courses</label>
    </div>
    </div>
 </div>
 
 
  <div class="col">
  <div className="card btn-group text-white bg-dark mb-3 border-info mb-3" style={{width:"350px",borderRadius:"60px",boxShadow:"4px 4px green"}} >
    <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/course-icon01.png"style={{width:"350px",height:"200px" ,backgroundColor:"lightblue"}} className="card-img-top" alt="..."/>
    <div div className="card-body">
      <h2 className="card-title"  style={{fontFamily:"Source Sans Pro"}}>IIT-JEE (Main+Advanced) </h2>
      <p className="card-text" style={{color:"white", fontSize:"9px"}}>ALLEN Career Institute guidance on JEE (Main+Advanced). Highly qualified faculties cover all the topics and equip students with concepts and techniques to perform in the test efficiently. At ALLEN gwalior, we provide special attention to each and every student on one to one basis. Our purpose is to deliver best results and assist students to make up to their potential.</p>
      <label class="btn btn-outline-primary" for="btncheck1">View Courses</label>
    
     </div>
  </div>
</div>
<div class="col">
  <div className="card btn-group text-white bg-dark mb-3 border-info mb-3" style={{width:"350px",borderRadius:"60px",boxShadow:"4px 4px green"}}>
    <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/course-icon05.png" style={{width:"350px",height:"200px" , backgroundColor:"lightblue"}}className="card-img-top" alt="..."/>
    <div className="card-body">
      <h2 className="card-title"style={{fontFamily:"Source Sans Pro"}}>Commerce</h2>
      <p className="card-text"style={{color:"white", fontSize:"9px"}}>Coaching Institute for the Lorem ipsum dolor sit amet consectetur. preparation of JEE (Main+Advanced), JEE (Main), Pre-Medical (NEET-UG), Pre-Nurture & Career Foundation (Class VI to X, NTSE & Olympiads) and Commerce Education (11th, 12th, CA & CS). The Institute is well regarded for the high quality entrance exam preparation and produces best results year after year. </p>
      <label class="btn btn-outline-primary" for="btncheck1">View Courses</label>
    
  </div>
  </div>
</div>
<div class="col">
  <div className="card  btn-group text-white bg-dark mb-3 border-info mb-3" style={{width:"350px",borderRadius:"60px",boxShadow:"4px 4px green"}} >
    <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/course-icon04.png"style={{width:"350px",height:"200px", backgroundColor:"lightblue"}} className="card-img-top" alt="..."/>
    <div className="card-body">
      <h2 className="card-title"  style={{fontFamily:"Source Sans Pro"}}>Pre-Nurture </h2>
      <p className="card-text" style={{color:"white", fontSize:"9px"}}>Pre-Nurture & Career Foundation (PNCF) courses at ALLEN kota are designed in such a way that the students’ understanding transforms from basic to the highest possible level and ensures a great success in school level education and upcoming competitive examinations Our Pre-Medical Division at ALLEN gwalior Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, ratione..</p>
      <label class="btn btn-outline-primary" for="btncheck1">View Courses</label>
    
    </div>
  </div>
</div>
<div class="col">
  <div className="card  btn-group text-white bg-dark mb-3 border-info mb-3" style={{width:"350px",borderRadius:"60px",boxShadow:"4px 4px green"}}>
    <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/course-icon06.png"style={{width:"350px",height:"200px" ,backgroundColor:"lightblue"}} className="card-img-top" alt="..."/>
    <div className="card-body">
      <h2 className="card-title"  style={{fontFamily:"Source Sans Pro"}}>Medical PG </h2>
      <p className="card-text" style={{color:"white", fontSize:"9px"}}>ALLEN is a leading coaching institute in India, renowned for its exceptional training programs for competitive exams such as NEET-UG, IIT-JEE (JEE Mains and Advanced), NTSE, KVPY, Boards, and Olympiads. Our staff works together seamlessly, and the educational philosophies of our HODs, combined with the visionary leadership of our Directors, have.</p>
      <label class="btn btn-outline-primary" for="btncheck1">View Courses</label>
    
     </div>
    </div>
</div>
<div class="col" >
  <div className="card  btn-group text-white bg-dark mb-3 border-info mb-3" style={{width: "350px",borderRadius:"60px",boxShadow:"4px 4px green"}}>
    <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/allen-new/course-icon02.png"style={{width:"350px",height:"200px", backgroundColor:"lightblue"}} className="card-img-top" alt="..."/>
    <div className="card-body">
      <h2 className="card-title"  style={{fontFamily:"Source Sans Pro"}}>JEE(Main) </h2>
      <p className="card-text" style={{color:"white", fontSize:"9px"}}>ALLEN CAREER INSTITUTE has established itself as a leader in the preparation for JEE Main. Year after year, it has given the best results in JEE Main. JEE Main courses designed by ALLEN are unique and are as per the latest examination pattern, which train the students to outperform in JEE Main exam. In order to draw the best out of the students and make them deliver top result.</p>
      <label class="btn btn-outline-primary" for="btncheck1">View Courses</label>
    
    </div>
    </div>
  </div>
  </div>
  </div>
</>      
      );
    };
    
    

export default Courses;