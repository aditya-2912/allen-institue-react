import { useEffect, useState } from "react";
import { Button, AppBar, Box, CssBaseline, IconButton, Toolbar, Typography, Menu, MenuItem } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import { styled, alpha } from '@mui/material/styles';
import SearchIcon from '@mui/icons-material/Search';

import InputBase from '@mui/material/InputBase';
import { classNames } from "@emotion/react";
export default function Admission(props) {

  return (
    <>
    <div className="container">
       
            <img src="https://allenwebsite-general.s3.ap-south-1.amazonaws.com/allen-website/landing-pages/national-landing-page/images/logo.png" alt="logo"style={{paddingTop:"70px"}}/>
       
    </div>
    <div className="container"style={{textAlign:"right"}}>
<h1 style={{paddingTop:"40px",fontSize:"60px"}}>Let ALLEN<br></br>
Guide You to<br></br>
<span style={{fontWeight:"bold",color:"darkblue"}}>A BETTER &<br></br>
BRIGHTER FUTURE</span></h1>
    </div>
<div className="container"style={{textAlign:"left"}}>
 
  <img src="https://myexam.allen.ac.in/wp-content/uploads/2023/01/Allen-Admission-Session-2023-24.jpg"style={{width:"50%",height:"60%"}}/>
</div>


<div className="container" style={{paddingTop:"20px"}}>
    <form className="row ">
  <div className="col-6"style={{paddingTop:"10px"}}>
    <label for="inputName4" className="form-label">Name</label>
    <input type="Name" className="form-control" id="inputName4" placeholder="Full Name" style={{backgroundColor:"lightgrey", border:"2px solid black",borderRadius:"25px"}}/>
  </div>
  <div className="col-6"style={{paddingTop:"10px"}}>
    <label for="inputEmail4" className="form-label">Email</label>
    <input type="Email" className="form-control" id="inputEmail4" placeholder="Email"style={{backgroundColor:"lightgrey", border:"2px solid black",borderRadius:"25px"}}/>
  </div>
  <div className="col-6"style={{paddingTop:"10px"}}>
    <label for="inputMobile" className="form-label">Mobile</label>
    <input type="text" className="form-control" id="inputMobile"  placeholder="+91" style={{backgroundColor:"lightgrey", border:"2px solid black",borderRadius:"25px"}}/>
  </div>
  <div className="col-6"style={{paddingTop:"10px"}}>
    <label for="input Study Mode" className="form-label">Study Mode</label>
    <select id="input Study Mode" className="form-select"style={{backgroundColor:"lightgrey", border:"2px solid black",borderRadius:"25px"}}>
      <option selected>Select Study Mode</option>
      <option>Classroom Program(Offline)</option>
      <option>ALLEN digital(Online)</option>
    </select>
  
  </div>
  <div className="col-md-6"style={{paddingTop:"10px"}}>
    <label for="inputCenter" className="form-label">Center</label>
    <select id="input Center" className="form-select"style={{backgroundColor:"lightgrey", border:"2px solid black",borderRadius:"25px"}}>
        <option selected>Select Center</option>
        <option>Kota</option>
        <option>Indore</option>
        <option>Gwalior</option>
        <option>Mumbai</option>
    </select>
  </div>
  <div className="col-md-6"style={{paddingTop:"10px"}}>
    <label for="inputClass" className="form-label">Class</label>
    <select id="inputClass" className="form-select"style={{backgroundColor:"lightgrey", border:"2px solid black",borderRadius:"25px"}}>
      <option selected>Select Class</option>
      <option>VI</option>
      <option>VII</option>
      <option>VIII</option>
      <option>IX</option>
      <option>X</option>
      <option>XI</option>
      <option>XII</option>
      <option>XII Passed</option>
    </select>
  </div>
  <div className="col-6"style={{paddingTop:'10px'}}>
    <label for="inputStream" className="form-label">Stream</label>
    <select id="input Stream" className="form-select"style={{backgroundColor:"lightgrey", border:"2px solid black",borderRadius:"25px"}}>
        <option>choose</option>
    </select>
    
  </div>
  <div className="col-6"style={{paddingTop:"10px"}}>
    <div className="form-check">
      <input className="form-check-input" type="checkbox" id="gridCheck"/>
      <label className="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <div className="col-6"style={{paddingTop:"20px"}}>
    <button type="submit" className="btn btn-primary">Sign in</button>
  </div>
</form>
</div>

    </>
  );
}