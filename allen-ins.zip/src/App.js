import "./App.css";
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import LandingPage from "./page/LandingPage";
import Admission from "./component/Admissionpage/Admission";
import About from "./component/Aboutpage/About";
import Contact from "./component/Contactspage/Contact";
import { useState,useEffect } from "react";
//import Modal from "./modal/modal";



function App() {
  const[count, setcount] =useState()

  useEffect(() =>{
    alert("i want a popup")

  },[]
  )
  return (
   
   <Router>
    <Routes>
    <Route element={<LandingPage/>} path="/home"/>
    <Route element={<Admission/>} path="/admission"/>
    <Route element={<About/>} path="/about"/>

   <Route element={<Contact/>} path="/contact"/>
    
    </Routes>
   </Router>
        
      

  );
}

export default App;
